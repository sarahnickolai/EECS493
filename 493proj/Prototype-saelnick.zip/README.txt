Name: Sarah Nickolai
NOTE: I was on a team with Eddy Lee and Chris Whinfrey, but I'm submitting my own prototype for now. Consult Professor Ackerman for the situation.

Date: April 9th, 2014
Class: EECS 493 Final Project Prototype

Asteroid Dodge:
Use the arrow keys to dodge asteroids above the surface of the Earth. If one hits you, you'll die!

To run:
Open Builds/AsteroidDodge.exe

Notable things:
Spinning Earth!
Spinning asteroids!
Random asteroid velocity, spin, and trajectory!
Asteroids gravitate towards Earth!
More asteroids as you continue to survive!